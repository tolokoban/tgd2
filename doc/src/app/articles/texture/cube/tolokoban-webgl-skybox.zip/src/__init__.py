bl_info = {
    "name": "Tolokoban WebGL Skybox",
    "author": "Tolokoban",
    "version": (1, 3),
    "blender": (4, 5, 0),
    "location": "View3D > Tolokoban",
    "description": "Generates the 6 images needed for a TextureCube in WebGL",
    "warning": "",
    "doc_url": "",
    "category": "",
}


import bpy
import math
import mathutils
from bpy.types import (Panel, Operator)
import pathlib
from distutils.dir_util import copy_tree

A = 0.7071067811865476
H = 0.5
faces = [
  [(-H, H, H, -H), "posX"],
  [(0, -1, 0, 0), "posY"],
  [(-H, H, -H, H), "negX"],
  [(-1, 0, 0, 0), "negY"],
  [(-A, A, 0, 0), "posZ"],
  [(0, 0, -A, A), "negZ"]
]

def generate_cameras():
    # Save the current active camera
    original_camera = bpy.context.scene.camera

    # Check if the collection "SkyboxCameras" exists, if not, create it
    collection_name = "SkyboxCameras"
    if collection_name not in bpy.data.collections:
        skybox_collection = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(skybox_collection)
    else:
        skybox_collection = bpy.data.collections[collection_name]    
    
    step = 0
    for (face, name) in faces:
        step = step + 1
        camera_name = f"Camera.{name}"
        # Create a new camera for this face
        if camera_name in bpy.data.objects:
            camera_object = bpy.data.objects[camera_name]
        else:
            # Create a new camera object
            camera_data = bpy.data.cameras.new(name=camera_name)
            camera_object = bpy.data.objects.new(camera_name, camera_data)
            skybox_collection.objects.link(camera_object)
        sensor_width = camera_object.data.sensor_width
        focal_length = (0.5 * sensor_width) / math.tan(0.25 * math.pi)    
        camera_object.data.lens = focal_length
        camera_object.location = (0, 0, 0)
        camera_object.rotation_mode = 'QUATERNION'
        quaternion = mathutils.Quaternion(face)
        camera_object.rotation_quaternion = quaternion
        bpy.data.cameras[camera_name].angle = math.pi / 2
    # Restore the original active camera
    bpy.context.scene.camera = original_camera

def load_and_show_image(file_path):
    """Loads a saved image into Blender's Image Editor."""
    # Use bpy.path.abspath to resolve the '//' relative path
    abs_filepath = bpy.path.abspath(file_path)
    
    # Try to load the image
    try:
        # Load the image into bpy.data.images
        # This will either load a new image or return an existing one if the path is the same
        image = bpy.data.images.load(abs_filepath, check_existing=True)
        return image
    except RuntimeError as e:
        print(f"Error loading image {abs_filepath}: {e}")
        return None
        
def render_skybox(resolution):
    generate_cameras()
    # Save current resolution
    original_resolution_x = bpy.data.scenes["Scene"].render.resolution_x
    original_resolution_y = bpy.data.scenes["Scene"].render.resolution_y
    original_resolution_percentage = bpy.data.scenes["Scene"].render.resolution_percentage
    
    bpy.data.scenes["Scene"].render.resolution_x = resolution
    bpy.data.scenes["Scene"].render.resolution_y = resolution
    bpy.data.scenes["Scene"].render.resolution_percentage = 100
    
    image_editor = None
    for area in bpy.context.screen.areas:
       if area.type == 'IMAGE_EDITOR':
           image_editor = area
           break
    bpy.context.window_manager.progress_begin(0, len(faces))
    step = 0
    for (face, name) in faces:
        step = step + 1
        camera_name = f"Camera.{name}"
        camera_object = bpy.data.objects[camera_name]
        # Update the progress bar
        bpy.context.window_manager.progress_update(step)
        # Set the camera as the active camera
        bpy.context.scene.camera = camera_object
        # Render the scene
        fmt = bpy.context.scene.skybox_format
        ext = 'webp' if fmt == 'WEBP' else 'png'
        bpy.context.scene.render.image_settings.file_format = fmt
        if fmt == 'WEBP':
            bpy.context.scene.render.image_settings.quality = bpy.context.scene.skybox_webp_quality
        bpy.context.scene.render.filepath = f'//Skybox/{name}.{ext}'
        bpy.ops.render.render(write_still=True)
        if image_editor:
            bpy.ops.image.open(filepath=bpy.path.abspath(bpy.context.scene.render.filepath))
            
        
    print("End.")
    bpy.context.window_manager.progress_end()
    if image_editor:
        with bpy.context.temp_override(area=image_editor):
            bpy.ops.render.view_show('INVOKE_DEFAULT')
       
    # Restore the original active camera and resolution
    bpy.data.scenes["Scene"].render.resolution_x = original_resolution_x
    bpy.data.scenes["Scene"].render.resolution_y = original_resolution_y
    bpy.data.scenes["Scene"].render.resolution_percentage = original_resolution_percentage
        
            
def select_camera(name):
    generate_cameras()
    camera_name = f"Camera.{name}"
    camera_object = bpy.data.objects[camera_name]
    bpy.context.scene.camera = camera_object
    bpy.ops.object.select_camera()
    bpy.ops.view3D.object_as_camera()

class GenerateCamerasButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.generate_cameras"
    bl_label = "Generate 6 Cameras"
    
    def execute(self, context):
        generate_cameras()
        return {'FINISHED'}
    
class SelectCameraNegXButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_negx"
    bl_label = "-X"
    
    def execute(self, context):
        select_camera("negX")
        return {'FINISHED'}
    
class SelectCameraNegYButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_negy"
    bl_label = "-Y"
    
    def execute(self, context):
        select_camera("negY")
        return {'FINISHED'}
    
class SelectCameraNegZButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_negz"
    bl_label = "-Z"
    
    def execute(self, context):
        select_camera("negZ")
        return {'FINISHED'}
    
class SelectCameraPosXButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_posx"
    bl_label = "+X"
    
    def execute(self, context):
        select_camera("posX")
        return {'FINISHED'}
    
class SelectCameraPosYButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_posy"
    bl_label = "+Y"
    
    def execute(self, context):
        select_camera("posY")
        return {'FINISHED'}
    
class SelectCameraPosZButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.select_camera_posz"
    bl_label = "+Z"
    
    def execute(self, context):
        select_camera("posZ")
        return {'FINISHED'}
    
class RenderSkyboxButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.render_skybox"
    bl_label = "Render Textures"
    
    def execute(self, context):
        # Get the resolution from the custom scene property
        resolution = context.scene.skybox_resolution
        render_skybox(resolution)
        return {'FINISHED'}
    
class GenerateHtmlButtonOperator(bpy.types.Operator):
    bl_idname = "tolokoban.generate_html"
    bl_label = "Generate HTML"
    
    def execute(self, context):
        html_path = pathlib.Path(__file__).parent.resolve() / "html"
        src = f"{html_path}"
        dst = bpy.path.abspath("//Skybox")
        print("SRC:", src)
        print("DST:", dst)
        copy_tree(src, dst)
        return {'FINISHED'}
    
#lets create the UIPanel Class
class WebGLSkyboxPanel(bpy.types.Panel):
    #lets set the label of the panel
    bl_label = "Web GL"
    bl_idname = "OBJECT_PT_tolokoban_webgl_skybox"
    
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Web GL"

    def draw(self, context):
        layout = self.layout
        scene = context.scene # Get a reference to the scene

        # Add the resolution property to the panel
        row0 = layout.row()
        row0.prop(scene, "skybox_resolution", text="Resolution (px)")
        
        row1 = layout.row()
        row1.prop(scene, "skybox_format", text="Format")
        
        if scene.skybox_format == 'WEBP':
            row_q = layout.row()
            row_q.prop(scene, "skybox_webp_quality", text="Quality", slider=True)
        
        row4 = layout.row()
        row4.operator(
            RenderSkyboxButtonOperator.bl_idname,
            text=RenderSkyboxButtonOperator.bl_label,
            icon="RENDER_RESULT"
        )

        layout.separator()

        row5 = layout.row()
        row5.operator(
            GenerateHtmlButtonOperator.bl_idname,
            text=GenerateHtmlButtonOperator.bl_label,
            icon="FILE"
        )
        
        layout.separator()

        selectors = [
            SelectCameraPosXButtonOperator,
            SelectCameraPosYButtonOperator,
            SelectCameraPosZButtonOperator,
        ]
        box = layout.box()
        box.label(text="Active orthographic camera")
        row2 = box.row()
        for selector in selectors:
            row2.operator(
                selector.bl_idname,
                text=selector.bl_label,
                icon="NONE"
            )
        selectors = [
            SelectCameraNegXButtonOperator,
            SelectCameraNegYButtonOperator,
            SelectCameraNegZButtonOperator,
        ]
        row3 = box.row()
        for selector in selectors:
            row3.operator(
                selector.bl_idname,
                text=selector.bl_label,
                icon="NONE"
            )
            
        
#lets import some functions to helps register our addon
from bpy.utils import register_class, unregister_class

# Set up a new property group to define the properties for the scene
def add_scene_properties():
    bpy.types.Scene.skybox_webp_quality = bpy.props.IntProperty(
        name="WebP Quality",
        description="Quality of the exported WebP images",
        default=90,
        min=0,
        max=100,
        subtype='PERCENTAGE',
    )
    bpy.types.Scene.skybox_format = bpy.props.EnumProperty(
        name="Image Format",
        items=[
            ('PNG', 'PNG', 'Export as PNG'),
            ('WEBP', 'WEBP', 'Export as WebP'),
        ],
        default='PNG',
    )
    bpy.types.Scene.skybox_resolution = bpy.props.IntProperty(
        name="Skybox Resolution",
        description="Resolution of the rendered skybox face images (must be square)",
        default=1024,
        min=1,
        soft_min=256,
        soft_max=4096,
        subtype='PIXEL'
    )

# Clean up the custom properties
def remove_scene_properties():
    del bpy.types.Scene.skybox_webp_quality
    del bpy.types.Scene.skybox_format
    del bpy.types.Scene.skybox_resolution

#lets set the classes we want to register
classes=[
    GenerateCamerasButtonOperator, 
    SelectCameraNegXButtonOperator,
    SelectCameraPosXButtonOperator,
    SelectCameraNegYButtonOperator,
    SelectCameraPosYButtonOperator,
    SelectCameraNegZButtonOperator,
    SelectCameraPosZButtonOperator,
    RenderSkyboxButtonOperator,
    GenerateHtmlButtonOperator,
    WebGLSkyboxPanel
]

#now lets register the classes
def register():
    add_scene_properties() # Register the custom property
    for clss in classes:
        register_class(clss)


def unregister():
    for clss in classes:
        unregister_class(clss)
    remove_scene_properties() # Unregister the custom property
        
        
if __name__ == "__main__":
    register()


const VERT = `#version 300 es

uniform vec2 uniScale;
uniform float uniLat;
uniform float uniLon;

in vec4 attPoint;
out vec3 varPoint;

void main() {
    float radius = cos(uniLat);
    float y = sin(uniLat);
    float x = radius * cos(uniLon);
    float z = radius * sin(uniLon);
    vec3 vecZ = vec3(x, y, z);
    vec3 vecFakeY = vec3(0, 1, 0);
    vec3 vecX = cross(vecFakeY, vecZ);
    vec3 vecY = cross(vecZ, vecX);
    mat3 mat = mat3(vecX, vecY, vecZ);
    varPoint =  mat * normalize(vec3(uniScale * attPoint.xy, 1.0));
    gl_Position = vec4(attPoint.xy, 0.5, 1.0);
}`

const FRAG = `#version 300 es

precision highp float;

uniform samplerCube uniTexture;

in vec3 varPoint;

out vec4 FragColor;

void main() {
    FragColor = texture(uniTexture, normalize(varPoint));
}`

/**
 * @param {string} id 
 * @returns {HTMLElement}
 */
function get(id) {
    const elem = document.getElementById(id)
    if (!elem) throw Error(`Unable for find element #${id}!`)
    return elem
}

/**
 * 
 * @param {string} url 
 * @param {()=>void} onLoad 
 * @returns {Promise<HTMLImageElement>}
 */
function loadImage(url, onLoad) {
    return new Promise(resolve => {
        const img = new Image()
        img.src = url
        const callback = () => {
            onLoad()
            resolve(img)
        }
        img.onload = callback
        img.onerror = callback
    })    
}

function createWebGLContext() {
    const canvas = get("canvas")
    if (!(canvas instanceof HTMLCanvasElement)) {
        throw Error("#canvas is not an instance of HTMLCanvasElement!")
    }

    const observer = new ResizeObserver(()=>{
        canvas.width = canvas.clientWidth
        canvas.height = canvas.clientHeight
    })
    observer.observe(canvas)
    /** @type {WebGLContextAttributes} */
    const options = {
        antialias: true,
        depth: false,
        preserveDrawingBuffer: false,
        stencil: false,
        alpha: false,
    }
    const gl = canvas.getContext("webgl2", options)
    if (!gl) throw Error("Unable to create WebGL 2 context!")

    return gl
}

/**
 * @param {WebGL2RenderingContext} gl 
 * @param {HTMLImageElement} negX 
 * @param {HTMLImageElement} negY 
 * @param {HTMLImageElement} negZ 
 * @param {HTMLImageElement} posX 
 * @param {HTMLImageElement} posY 
 * @param {HTMLImageElement} posZ 
 */
function createTexture(gl, negX, negY, negZ, posX, posY, posZ) {
    const texture = gl.createTexture()
    if (!texture) throw new Error("Unable to create a WebGLTexture!")

    const flipY = gl.getParameter(gl.UNPACK_FLIP_Y_WEBGL)
    /** @type {Array<[number, HTMLImageElement]>} */
    const faces = [
        [gl.TEXTURE_CUBE_MAP_POSITIVE_X, posX],
        [gl.TEXTURE_CUBE_MAP_NEGATIVE_X, negX],
        [gl.TEXTURE_CUBE_MAP_POSITIVE_Y, posY],
        [gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, negY],
        [gl.TEXTURE_CUBE_MAP_POSITIVE_Z, posZ],
        [gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, negZ],
    ]
    for (const [target, image] of faces) {
        gl.bindTexture(gl.TEXTURE_CUBE_MAP, texture)
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, image instanceof Image)
        gl.texImage2D(target, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image)
    }
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, flipY)
    gl.generateMipmap(gl.TEXTURE_CUBE_MAP)
    gl.texParameteri(
        gl.TEXTURE_CUBE_MAP,
        gl.TEXTURE_MIN_FILTER,
        gl.LINEAR_MIPMAP_LINEAR
    )
    return texture
}

/**
 * @param {WebGL2RenderingContext} gl 
 * @param {"VERTEX_SHADER" | "FRAGMENT_SHADER"} type
 * @param {string} code
 */
function createShader(gl, type, code) {
    const shader = gl.createShader(gl[type])
    if (!shader)
        throw new Error(`Unable to create a WebGLShader of type "${type}"!`)

    gl.shaderSource(shader, code)
    gl.compileShader(shader)
    return shader
}

/**
 * @param {WebGL2RenderingContext} gl 
 */
function createProgram(gl) {
    const prg = gl.createProgram()
    if (!prg) throw new Error("Unable to create WebGLProgram!")

    const vertShader = createShader(gl, "VERTEX_SHADER", VERT)
    gl.attachShader(prg, vertShader)
    const fragShader = createShader(gl, "FRAGMENT_SHADER", FRAG)
    gl.attachShader(prg, fragShader)
    gl.linkProgram(prg)
    gl.detachShader(prg, vertShader)
    gl.deleteShader(vertShader)
    gl.detachShader(prg, fragShader)
    gl.deleteShader(fragShader)

    return prg
}

/**
 * 
 * @param {WebGL2RenderingContext} gl 
 * @param {WebGLProgram} prg 
 * @returns 
 */
function createVAO(
  gl,
  prg
) {
  const data0 = new Float32Array([-1, +1, +1, +1, -1, -1, +1, -1])
  const vao = gl.createVertexArray()
  gl.bindVertexArray(vao)
  const buff0 = gl.createBuffer()
  gl.bindBuffer(gl.ARRAY_BUFFER, buff0)
  gl.bufferData(gl.ARRAY_BUFFER, data0, gl.STATIC_DRAW)
  const $attPoint = gl.getAttribLocation(prg, "attPoint")
  gl.enableVertexAttribArray($attPoint)
  gl.vertexAttribPointer(
    $attPoint,
    2,  // Dimension
    gl.FLOAT,
    false,
    8,   // Stride
    0   // Offset
  )
  gl.vertexAttribDivisor($attPoint, 0)
  return vao
}


async function start() {
    let imagesLoaded = 1
    const [negX, negY, negZ, posX, posY, posZ] = await Promise.all(["negX", "negY", "negZ", "posX", "posY", "posZ"].map(
        name => loadImage(`${name}.webp`, ()=>{
            get("count").textContent = `${imagesLoaded++}`
        })
    ))
    const gl = createWebGLContext()
    const texture = createTexture(gl, negX, negY, negZ, posX, posY, posZ)
    const prg = createProgram(gl)
    const vao = createVAO(gl, prg)
    const uniTexture = gl.getUniformLocation(prg, "uniTexture")
    const uniScale = gl.getUniformLocation(prg, "uniScale")
    const uniLat = gl.getUniformLocation(prg, "uniLat")
    const uniLon = gl.getUniformLocation(prg, "uniLon")
    let lat = 0
    let lon = 0
    gl.canvas.addEventListener("pointermove", evt => {
        const rect = gl.canvas.getBoundingClientRect()
        const x = 2 * (evt.clientX - rect.x) / rect.width - 1
        const y = 2 * (evt.clientY - rect.y) / rect.height - 1
        lon = Math.PI * x
        lat = 3.1415 * y / 3
    })

    /** @type {(time: number) => void} */
    const anim = (time) => {
        const w = gl.drawingBufferWidth
        const h = gl.drawingBufferHeight
        gl.viewport(0, 0, w, h)
        gl.useProgram(prg)
        gl.bindVertexArray(vao)
        if (w > h) {
            // Landscape
            gl.uniform2f(uniScale, 1, h / w)
        }else{
            // Portrait
            gl.uniform2f(uniScale, w / h, 1)
        }
        const unit = 0
        gl.activeTexture(gl.TEXTURE0 + unit)
        gl.bindTexture(gl.TEXTURE_CUBE_MAP, texture)
        gl.uniform1i(uniTexture, unit)
        gl.uniform1f(uniLat, lat)
        gl.uniform1f(uniLon, lon)
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
        requestAnimationFrame(anim)
    }
    requestAnimationFrame(anim)

    get("tgd-logo").style.opacity = "0"
}

start()